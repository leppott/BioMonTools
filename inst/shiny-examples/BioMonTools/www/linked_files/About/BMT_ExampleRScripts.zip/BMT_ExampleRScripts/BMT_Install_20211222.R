library(devtools)

remotes::install_github("leppott/BioMonTools", force = TRUE)


library(BioMonTools)

help(package="BioMonTools")
