library(readxl)
library(knitr)
library(BioMonTools)

# set working directory
wd <-'C:/Users/Jen.Stamp/Documents/R_code/BioMonTools_4.3.C/MetricCalc'
setwd(wd)

# load data
df.data <- read.csv("C:/Users/Jen.Stamp/Documents/R_code/BioMonTools_4.3.C/MetricCalc/MetricInput1.csv")


# Metrics of Interest
## total taxa and individs, EPT, thermal indicator (_ti_)
col.met2keep <- c("ni_total", "nt_total", "nt_EPT", "pi_EPT", "pt_EPT", "nt_ti_cc", "nt_ti_w", 
                  "pi_ti_cc", "pi_ti_w", "pt_ti_cc", "pt_ti_w")

# Run Function
df.metval <- metric.values(df.data, "bugs"
                           , fun.MetricNames = col.met2keep)


# Ouput
df.metval.select <- df.metval[, c(col.met2keep)]


# write results
write.csv(df.metval, "MetricOutput1_select.csv")