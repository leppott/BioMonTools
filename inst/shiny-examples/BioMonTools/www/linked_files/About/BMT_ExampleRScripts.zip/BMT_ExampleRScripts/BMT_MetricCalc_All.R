library(readxl)
library(knitr)
library(BioMonTools)

# read in the file
wd <-'C:/Users/Jen.Stamp/Documents/R_code/BioMonTools_4.3.C/MetricCalc'
setwd(wd)
df_data <- read.csv("C:/Users/Jen.Stamp/Documents/R_code/BioMonTools_4.3.C/MetricCalc/MetricInput1.csv")


# run function
df_metval <- metric.values(df_data, "bugs")

# write results
write.csv(df_metval, "MetricOutput1_AllMetrics.csv")
